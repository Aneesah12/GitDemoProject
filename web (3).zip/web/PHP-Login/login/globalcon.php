<?php
//SYSTEM SETTINGS
//$base_url = '' . $_SERVER['SERVER_NAME'];
$base_url = 'localhost:8000/PHP-Login/login/verifyuser.php';
//$signin_url = substr($base_url . $_SERVER['PHP_SELF'], 0, -(6 + strlen(basename($_SERVER['PHP_SELF']))));//
$signin_url = 'localhost:8000/PHP-Login/login/verifyuser.php';

//DO NOT CHANGE
$ip_address = $_SERVER['REMOTE_ADDR'];
